from flask import Blueprint

main = Blueprint('main', __name__)

@main.route('/')
def home():
    return "App Flask rodando com sucesso!"